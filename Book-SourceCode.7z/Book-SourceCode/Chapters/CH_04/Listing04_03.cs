﻿//using System;
//namespace CH_04
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Book book = new Book("The Future of the mind");
//            book.Print();
//        }
//    }

//    public class Book
//    {
//        private string Name;
//        public Book(string bookName) { Name = bookName; }
//        public void Print()
//        {
//            Console.WriteLine(Name);
//        }
//    }
//}
