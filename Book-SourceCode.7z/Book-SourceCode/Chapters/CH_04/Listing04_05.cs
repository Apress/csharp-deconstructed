﻿//using System;
//namespace CH_04
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Book book = new Book();
//            book.MethodOne();
//        }
//    }

//    public class Book
//    {
//        public void MethodOne() { Console.WriteLine(ToString()); }
//        public void MethodTwo() { Console.WriteLine(ToString()); }
//    }
//}