﻿using System;
namespace CH_04
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Virtual to Physical address mappings");
            Console.ReadLine();
        }
    }
}
