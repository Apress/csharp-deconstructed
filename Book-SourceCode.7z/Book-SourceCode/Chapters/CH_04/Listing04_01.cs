﻿//using System;
//namespace CH_04
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.WriteLine("The Future of the mind");
//        }
//    }
//}