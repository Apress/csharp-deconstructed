﻿//using System;
//namespace CH_04
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Book book = new Book();
//        }
//    }

//    public class Book
//    {
//        public void TestMethod_1() { int i = 0; Console.WriteLine(++i); }
//        public void TestMethod_2() { int i = 0; Console.WriteLine(++i); }
//        public void TestMethod_3() { int i = 0; Console.WriteLine(++i); }
//        public void TestMethod_4() { int i = 0; Console.WriteLine(++i); }
//        public void TestMethod_5() { int i = 0; Console.WriteLine(++i); }
//        public void TestMethod_6() { int i = 0; Console.WriteLine(++i); }
//    }
//}
