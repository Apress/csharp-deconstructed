﻿using System;

namespace CH_05
{
    class Program
    {
        static void Main(string[] args)
        {
            TestClass testClass = new TestClass();
            testClass.Method_1();
            Console.ReadLine();
        }
    }

    public class TestClass
    {
        public void Method_1() { }
    }
}
