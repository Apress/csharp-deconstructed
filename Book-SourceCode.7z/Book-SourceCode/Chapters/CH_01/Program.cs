﻿using System;

namespace Ch_01
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Read();
            ClassTest ct = new ClassTest();
            while (true)
            {
                if (Console.ReadKey().Key == ConsoleKey.A)
                    break;
            }
        }
    }

    public class ClassTest
    {
        public void One() { }
        public void Two() { }
        public void Three() { }
    }

}
