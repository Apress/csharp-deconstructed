﻿using System;

namespace CH_03
{
    class Program
    {
        static void Main(string[] args)
        {
            Book book = new Book();
            book.Print();
        }
    }
    public class Book
    {
        public void Print() { Console.WriteLine("Blue Sky."); }
    }
}
