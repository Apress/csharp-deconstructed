﻿using System;

namespace Ch_07
{
    class Program
    {
        static void Main(string[] args)
        {
            ClassTest ct = new ClassTest();
            ct.One();
        }
    }

    public class ClassTest
    {
        public void One()
        {
            Console.WriteLine("Hello World");
        }
        public void Two() { }
        public void Three() { }
    }
}
